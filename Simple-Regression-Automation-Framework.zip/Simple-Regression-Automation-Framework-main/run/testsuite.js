const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;
let testResults = [];  // To store individual test results

function deleteUserDataDir() {
    const userDataDir = './user_data';
    if (fs.existsSync(userDataDir)) {
        fs.rmSync(userDataDir, { recursive: true, force: true });
    }
}

function writeReportToOutputs(filename, data) {
    const cwd = process.cwd();
    const subfolderPath = path.join(cwd, 'outputs');
    const fullFilePath = path.join(subfolderPath, filename);
    if (!fs.existsSync(subfolderPath)) {
        fs.mkdirSync(subfolderPath, { recursive: true });
    }
    fs.writeFileSync(fullFilePath, data);
}

function generateReportHTML(totalTests, passedTests, failedTests, inputFilename) {
    const passedPercentage = (passedTests / totalTests) * 100;
    const failedPercentage = (failedTests / totalTests) * 100;

    let testResultsHtml = testResults.map(result => `
    <tr>
        <td>${result.assertion}</td>
        <td>${result.result}</td>
        <td>${result.message}</td>
    </tr>
    `).join('');

    return `
    <html>
    <head>
        <title>Test Report</title>
        <style>
            body { font-family: Arial, sans-serif; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            tr:nth-child(even) { background-color: #f2f2f2; }
        </style>
    </head>
    <body>
        <h2>Test Report for ${inputFilename}</h2>
        <h3>Summary</h3>
        <table>
            <tr>
                <td>Total tests</td>
                <td>${totalTests}</td>
            </tr>
            <tr>
                <td>Passed</td>
                <td>${passedTests}</td>
            </tr>
            <tr>
                <td>Failed</td>
                <td>${failedTests}</td>
            </tr>
            <tr>
                <td>Passed Percentage</td>
                <td>${passedPercentage.toFixed(2)}%</td>
            </tr>
            <tr>
                <td>Failed Percentage</td>
                <td>${failedPercentage.toFixed(2)}%</td>
            </tr>
        </table>
        <h3>Test Details</h3>
        <table>
            <thead>
                <tr>
                    <th>Assertion</th>
                    <th>Result</th>
                    <th>Message</th>
                </tr>
            </thead>
            <tbody>
                ${testResultsHtml}
            </tbody>
        </table>
    </body>
    </html>
    `;
}

const config = JSON.parse(fs.readFileSync('../run/config.json', 'utf-8'));
const args = process.argv.slice(2);
const filename = args[0];
let useProxy = false;

if (args.includes('--useProxy')) {
  useProxy = true;
}

if (!filename) {
  console.error('Please provide the filename as a command-line parameter.');
  process.exit(1);
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

let browser;

async function getBrowser() {
  if (!browser) {
    const userDataDir = './user_data';
	
	const launchOptions = {
	  headless: config.headless === "old" ? true : (config.headless === "new" ? "new" : false),
	  userDataDir,
	  ignoreHTTPSErrors: true,
	};


    if (useProxy) {
      launchOptions.args = [`--proxy-server=${config.proxy}`];
    }

    browser = await puppeteer.launch(launchOptions);
  }
  return browser;
}


async function processCommandFile(filename, options = {}) {
	
  let testFailed = false;
  const fileContent = fs.readFileSync(filename, 'utf-8');
  //console.log(`\nStarting the test with file: ${filename}\nCommands:\n${fileContent}\n`);
  console.log(`\nRunning Test: ${filename}`);
  
  function writeToOutputs(filename, data) {
    const cwd = process.cwd();
    const subfolderPath = path.join(cwd, 'outputs');
    const fullFilePath = path.join(subfolderPath, filename);

    if (!fs.existsSync(subfolderPath)) {
      fs.mkdirSync(subfolderPath, { recursive: true });
    }

    fs.writeFileSync(fullFilePath, data);
  }

  const browser = await getBrowser();
  const context = await browser.createIncognitoBrowserContext();
  const page = await context.newPage();

  if (options.proxy && options.proxyCredentials) {
    await page.authenticate(options.proxyCredentials);
  }

  const commands = fileContent.split('\n').filter(line => Boolean(line.trim()) && !line.trim().startsWith('#'));
  let testResult = 'Test result: success';

  for (let i = 0; i < commands.length; i++) {
    const parts = commands[i].match(/"[^"]+"|\S+/g).map(p => p.replace(/"/g, '').trim());

    try {
      switch (parts[0]) {
        case 'open':
          await page.goto(parts[1]);
          console.log(`Assertion ${i + 1} Success: Opened ${parts[1]}`);
          break;
        case 'observe':
          await page.waitForFunction(`document.documentElement.textContent.includes("${parts[1]}")`);
          console.log(`Assertion ${i + 1} Success: Found text "${parts[1]}"`);
          break;
        case 'click':
          if (parts[1].startsWith('#')) {
            await page.click(parts[1]);
            console.log(`Assertion ${i + 1} Success: Clicked on "${parts[1]}"`);
          } else {
            await page.waitForXPath(`//a[contains(text(), '${parts[1]}')]`);
            const linkToClick = await page.$x(`//a[contains(text(), '${parts[1]}')]`);
            if (linkToClick.length > 0) {
              await linkToClick[0].click();
            } else {
              throw new Error(`Link not found: ${parts[1]}`);
            }
            console.log(`Assertion ${i + 1} Success: Clicked link "${parts[1]}"`);
          }
          break;
        case 'wait':
          await page.waitForNavigation();
          console.log(`Assertion ${i + 1} Success: Waited for new page to load`);
          break;
        case 'delay':
          const duration = parseInt(parts[1], 10);
          if (isNaN(duration)) {
            throw new Error(`Invalid duration: ${parts[1]}`);
          }
          await new Promise(resolve => setTimeout(resolve, duration));
          console.log(`Assertion ${i + 1} Success: Delayed for ${duration} ms`);
          break;
		  
		case 'print':
			// This gives the directory from where the script was called
			const cwd = process.cwd();

			// Now, create a path for the outputs subfolder within the cwd
			const subfolderPath = path.join(cwd, 'outputs');
			const fullFilePath = path.join(subfolderPath, parts[1]);

			// Check if subfolder exists, if not create it
			if (!fs.existsSync(subfolderPath)) {
				fs.mkdirSync(subfolderPath, { recursive: true });
			}

			const html = await page.content();
			fs.writeFileSync(fullFilePath, html);
			console.log(`Assertion ${i + 1} Success: Printed HTML of the current page to "${fullFilePath}"`);
			break;

		  
        case 'input':
          const elementSelector = parts[1].startsWith('#') ? parts[1] : `[name="${parts[1]}"]`;
          const value = parts[2];
          await page.type(elementSelector, value);
          console.log(`Assertion ${i + 1} Success: Entered "${value}" into "${elementSelector}"`);
          break;
        case 'submit':
          await page.evaluate(formId => {
            const form = document.querySelector(formId);
            if (form) {
              form.submit();
            } else {
              throw new Error(`Form not found: ${formId}`);
            }
          }, parts[1]);
          console.log(`Assertion ${i + 1} Success: Submitted form "${parts[1]}"`);
          break;
        case 'login':
          const usernameSelector = parts[1];
          const username = parts[2];
          const passwordSelector = parts[3];
          const password = parts[4];
          await page.type(usernameSelector, username);
          await page.type(passwordSelector, password);
          console.log(`Assertion ${i + 1} Success: Entered login information and logged in`);
          break;
		  
		case 'clickInputButton':
		  const buttonValue = parts[1];
		  await page.waitForXPath(`//input[@type='submit' and @value='${buttonValue}']`);
		  const buttons = await page.$x(`//input[@type='submit' and @value='${buttonValue}']`);
		  if (buttons.length > 0) {
			await buttons[0].click();
		  } else {
			throw new Error(`Input button not found: ${buttonValue}`);
		  }
		  console.log(`Assertion ${i + 1} Success: Clicked input button "${buttonValue}"`);
		  break;

		case 'clickElement':
                await page.waitForSelector(parts[1]);
                const element = await page.$(parts[1]);
                if (element) {
                    await element.click();
                    console.log(`Assertion ${i + 1} Success: Clicked on element with selector "${parts[1]}".`);
                } else {
                    throw new Error(`Element not found with selector "${parts[1]}".`);
                }
                break;

		case 'post':
			const postUrl = parts[1];
			const body = JSON.parse(parts[2]);
			lastResponse = await page.evaluate(async (url, body) => {
				const response = await fetch(url, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(body),
				});
				return await response.json();
			}, postUrl, body);
			writeToOutputs(`postResponse_${Date.now()}.json`, JSON.stringify(lastResponse, null, 2));
			console.log(`Assertion ${i + 1} Success: Made POST request to "${postUrl}", saved response to "outputs" folder.`);
			break;

		case 'get':
			const getUrl = parts[1];
			lastResponse = await page.evaluate(async (url) => {
				const response = await fetch(url, {
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
					},
				});
				return await response.json();
			}, getUrl);
			writeToOutputs(`getResponse_${Date.now()}.json`, JSON.stringify(lastResponse, null, 2));
			console.log(`Assertion ${i + 1} Success: Made GET request to "${getUrl}", saved response to "outputs" folder.`);
			break;


		case 'observeResponse':
		  const expectedResponseText = parts[1];
		  if (lastResponse && JSON.stringify(lastResponse).includes(expectedResponseText)) {
			console.log(`Assertion ${i + 1} Success: Found text "${expectedResponseText}" in the last response`);
		  } else {
			throw new Error(`Text not found: ${expectedResponseText}`);
		  }
		  break;


		case 'writeResponseToFile':
			if (!lastResponse) {
				throw new Error('No response available to write to file');
			}
			writeToOutputs(`lastResponse_${Date.now()}.json`, JSON.stringify(lastResponse, null, 2));
			console.log(`Assertion ${i + 1} Success: Wrote last response to the "outputs" folder.`);
			break;

		  
        default:
          throw new Error(`Unknown command "${parts[0]}"`);
      }
      await delay(1000);
      console.log(`Assertion ${i + 1} Success: [command completed succesfully]`);
	  testResults.push({
			assertion: commands[i],
			result: 'Success',
			message: `[command completed succesfully]`
	   });
	  
	  
    } catch (e) {
	  testFailed = true; 
	  console.log(`Assertion ${i + 1} Failure: ${e.message}`);
	  testResults.push({
			assertion: commands[i],
			result: 'Failure',
			message: e.message
	  });



	  testResult = 'Test result: failure'	
      testFailed = true; 
      console.log(`Assertion ${i + 1} Failure: ${e.message}`);
    }
	
  }

  console.log(testResult);
  totalTests++;
  if (testFailed) {
      failedTests++;
  } else {
      passedTests++;
  }

  try {
    await page.close();
  } catch (error) {
    console.warn('Page might have already been closed:', error.message);
  }

  await context.close();
}

async function runCommandFiles(inputFilename) {
  const fileList = fs.readFileSync(inputFilename, 'utf-8').split('\n').filter(line => Boolean(line.trim()));

  for (const file of fileList) {
    await processCommandFile(file, useProxy ? {
      proxy: config.proxy,
      proxyCredentials: config.proxyCredentials,
    } : {});
  }

  console.log("\n========== Final Report ==========");
  console.log("\nTest Suite: " + inputFilename + "\n");
  console.log(`Total tests: ${totalTests}`);

  const passedPercentage = (passedTests / totalTests) * 100;
  const failedPercentage = (failedTests / totalTests) * 100;

  console.log(`Passed: ${passedTests} (%${passedPercentage.toFixed(2)})`);
  console.log(`Failed: ${failedTests} (%${failedPercentage.toFixed(2)})`);

  const reportHtml = generateReportHTML(totalTests, passedTests, failedTests,inputFilename);
  writeReportToOutputs(inputFilename + "-report.html", reportHtml); 
  
  if (browser) {
    await browser.close();
    deleteUserDataDir();
  }
}

runCommandFiles(filename);

