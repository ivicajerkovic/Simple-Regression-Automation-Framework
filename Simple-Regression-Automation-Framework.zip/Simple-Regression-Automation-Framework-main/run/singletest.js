// Import required modules
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// Utility function to delete the user_data directory
function deleteUserDataDir() {
    const userDataDir = './user_data';
    if (fs.existsSync(userDataDir)) {
        try {
            fs.rmSync(userDataDir, { recursive: true, force: true });
            //console.log(`Deleted ${userDataDir} directory`);
        } catch (error) {
            //console.error(`Failed to delete ${userDataDir} directory. Error: ${error.message}`);
        }
    }
}


// Read the configuration from the config file
const config = JSON.parse(fs.readFileSync('../run/config.json', 'utf-8'));

// Parse command line arguments
const args = process.argv.slice(2);
const filename = args[0];
let useProxy = false;

// Declare a global variable to store the last response
let lastResponse = null;


if (args.includes('--useProxy')) {
  useProxy = true;
}

// Check if the filename is provided
if (!filename) {
  console.error('Please provide the filename as a command-line parameter.');
  process.exit(1);
}

// Delay function
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// global variable to hold the browser instance
let browser;

// Create a new instance of the browser or return the existing one
async function getBrowser() {
  if (!browser) {
    const userDataDir = './user_data'; // choose a directory to store session data

	const launchOptions = {
	  headless: config.headless === "old" ? true : (config.headless === "new" ? "new" : false),
	  userDataDir,
	  ignoreHTTPSErrors: true,
	};

    if (useProxy) {
      launchOptions.args = [`--proxy-server=${config.proxy}`];
    }

    browser = await puppeteer.launch(launchOptions);
  }

  return browser;
}

// This function runs the commands from the file
async function runCommands(filename, options = {}) {
  const fileContent = fs.readFileSync(filename, 'utf-8');
  console.log(`\nStarting the test with file: ${filename}\nFile Content:\n${fileContent}\n`);


  function writeToOutputs(filename, data) {
		const cwd = process.cwd();
		const subfolderPath = path.join(cwd, 'outputs');
		const fullFilePath = path.join(subfolderPath, filename);

		// Check if subfolder exists, if not create it
		if (!fs.existsSync(subfolderPath)) {
			fs.mkdirSync(subfolderPath, { recursive: true });
		}

		fs.writeFileSync(fullFilePath, data);
  }

  const browser = await getBrowser();
  
  // Create an incognito browser context
  const context = await browser.createIncognitoBrowserContext();

  // Open a new page in that context
  const page = await context.newPage();


  // If a proxy server is specified in the options, authenticate it
  if (options.proxy && options.proxyCredentials) {
    await page.authenticate(options.proxyCredentials);
  }

  // Read the commands from the file, split them by line, and filter out empty lines and comments
  const commands = fileContent.split('\n').filter(line => Boolean(line.trim()) && !line.trim().startsWith('#'));


  // Variable to keep track of test results
  let testResult = 'Test: success';


  // Loop over each command
  for (let i = 0; i < commands.length; i++) {
    // Split the command into parts, handling quoted arguments correctly
    const parts = commands[i].match(/"[^"]+"|\S+/g).map(p => p.replace(/"/g, '').trim());

    // Try to execute the command and catch any errors
    try {
      // Use a switch statement to handle different commands
      switch (parts[0]) {
        case 'open':
          await page.goto(parts[1]);
          console.log(`Assertion ${i + 1} Success: Opened ${parts[1]}`);
          break;
        case 'observe':
          await page.waitForFunction(`document.documentElement.textContent.includes("${parts[1]}")`);
          console.log(`Assertion ${i + 1} Success: Found text "${parts[1]}"`);
          break;
        case 'click':
          if (parts[1].startsWith('#')) {
            await page.click(parts[1]);
            console.log(`Assertion ${i + 1} Success: Clicked on "${parts[1]}"`);
          } else {
            await page.waitForXPath(`//a[contains(text(), '${parts[1]}')]`);
            const linkToClick = await page.$x(`//a[contains(text(), '${parts[1]}')]`);
            if (linkToClick.length > 0) {
              await linkToClick[0].click();
            } else {
              throw new Error(`Link not found: ${parts[1]}`);
            }
            console.log(`Assertion ${i + 1} Success: Clicked link "${parts[1]}"`);
          }
          break;
        case 'wait':
          await page.waitForNavigation();
          console.log(`Assertion ${i + 1} Success: Waited for new page to load`);
          break;
        case 'delay':
          const duration = parseInt(parts[1], 10);
          if (isNaN(duration)) {
            throw new Error(`Invalid duration: ${parts[1]}`);
          }
          await new Promise(resolve => setTimeout(resolve, duration));
          console.log(`Assertion ${i + 1} Success: Delayed for ${duration} ms`);
          break;
		  
		case 'print':
			// This gives the directory from where the script was called
			const cwd = process.cwd();

			// Now, create a path for the outputs subfolder within the cwd
			const subfolderPath = path.join(cwd, 'outputs');
			const fullFilePath = path.join(subfolderPath, parts[1]);

			// Check if subfolder exists, if not create it
			if (!fs.existsSync(subfolderPath)) {
				fs.mkdirSync(subfolderPath, { recursive: true });
			}

			const html = await page.content();
			fs.writeFileSync(fullFilePath, html);
			console.log(`Assertion ${i + 1} Success: Printed HTML of the current page to "${fullFilePath}"`);
			break;

		  
        case 'input':
          const elementSelector = parts[1].startsWith('#') ? parts[1] : `[name="${parts[1]}"]`;
          const value = parts[2];
          await page.type(elementSelector, value);
          console.log(`Assertion ${i + 1} Success: Entered "${value}" into "${elementSelector}"`);
          break;
        case 'submit':
          await page.evaluate(formId => {
            const form = document.querySelector(formId);
            if (form) {
              form.submit();
            } else {
              throw new Error(`Form not found: ${formId}`);
            }
          }, parts[1]);
          console.log(`Assertion ${i + 1} Success: Submitted form "${parts[1]}"`);
          break;
        case 'login':
          const usernameSelector = parts[1];
          const username = parts[2];
          const passwordSelector = parts[3];
          const password = parts[4];
          await page.type(usernameSelector, username);
          await page.type(passwordSelector, password);
          console.log(`Assertion ${i + 1} Success: Entered login information and logged in`);
          break;
		  
		case 'clickInputButton':
		  const buttonValue = parts[1];
		  await page.waitForXPath(`//input[@type='submit' and @value='${buttonValue}']`);
		  const buttons = await page.$x(`//input[@type='submit' and @value='${buttonValue}']`);
		  if (buttons.length > 0) {
			await buttons[0].click();
		  } else {
			throw new Error(`Input button not found: ${buttonValue}`);
		  }
		  console.log(`Assertion ${i + 1} Success: Clicked input button "${buttonValue}"`);
		  break;

		case 'clickElement':
                await page.waitForSelector(parts[1]);
                const element = await page.$(parts[1]);
                if (element) {
                    await element.click();
                    console.log(`Assertion ${i + 1} Success: Clicked on element with selector "${parts[1]}".`);
                } else {
                    throw new Error(`Element not found with selector "${parts[1]}".`);
                }
                break;
				
		case 'post':
			const postUrl = parts[1];
			const body = JSON.parse(parts[2]);
			lastResponse = await page.evaluate(async (url, body) => {
				const response = await fetch(url, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(body),
				});
				return await response.json();
			}, postUrl, body);
			writeToOutputs(`postResponse_${Date.now()}.json`, JSON.stringify(lastResponse, null, 2));
			console.log(`Assertion ${i + 1} Success: Made POST request to "${postUrl}", saved response to "outputs" folder.`);
			break;

		case 'get':
			const getUrl = parts[1];
			lastResponse = await page.evaluate(async (url) => {
				const response = await fetch(url, {
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
					},
				});
				return await response.json();
			}, getUrl);
			writeToOutputs(`getResponse_${Date.now()}.json`, JSON.stringify(lastResponse, null, 2));
			console.log(`Assertion ${i + 1} Success: Made GET request to "${getUrl}", saved response to "outputs" folder.`);
			break;


		case 'observeResponse':
		  const expectedResponseText = parts[1];
		  if (lastResponse && JSON.stringify(lastResponse).includes(expectedResponseText)) {
			console.log(`Assertion ${i + 1} Success: Found text "${expectedResponseText}" in the last response`);
		  } else {
			throw new Error(`Text not found: ${expectedResponseText}`);
		  }
		  break;


		case 'writeResponseToFile':
			if (!lastResponse) {
				throw new Error('No response available to write to file');
			}
			writeToOutputs(`lastResponse_${Date.now()}.json`, JSON.stringify(lastResponse, null, 2));
			console.log(`Assertion ${i + 1} Success: Wrote last response to the "outputs" folder.`);
			break;

		  
        default:
          throw new Error(`Unknown command "${parts[0]}"`);
      }
      await delay(1000);
    } catch (e) {
      testResult = 'Test: failed';
      console.log(`Assertion ${i + 1} Failure: ${e.message}`);
    }
  }

  console.log(testResult);
  
  await page.close();
  
  // Close the browser instance.
  await browser.close();  
  deleteUserDataDir();
}

// Call the function with the filename of your command file and an options object
runCommands(filename, useProxy ? {
  proxy: config.proxy,
  proxyCredentials: config.proxyCredentials,
} : {});
